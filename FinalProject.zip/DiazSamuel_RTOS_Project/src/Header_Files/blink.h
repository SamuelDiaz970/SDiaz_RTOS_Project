/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#include  <kernel/include/os.h>
#include "app.h"
#include  <bsp_os.h>
#include  "bsp.h"
#include <stdint.h>
#include <stdbool.h>
#include "em_emu.h"
#include  <common/include/common.h>
#include <stdlib.h>
#include "em_device.h"
#include "em_cmu.h"
#include "em_chip.h"
#include "em_core.h"
#include "display.h"
#include "retargettextdisplay.h"
#include <stdio.h>
#include "textdisplay.h"
#include "glib.h"
#include "dmd.h"
#include <string.h>
#include "capsense.h"

#ifndef BLINK_H
#define BLINK_H

#include "gpio.h"
#include <string.h>

//Task Defines
#define TASK_STACK_SIZE      		512
#define LCD_TASK_PRIO            	20
#define PHYS_TASK_PRIO				21
#define BALL_TASK_PRIO				22
#define CAP_TASK_PRIO				23
#define BOOST_TASK_PRIO				24

//Game Defines
#define REFRESHRATE					60
#define LEFTBOUND 					3
#define RIGHTBOUND					124	
#define TOPBOUND					-50
#define BOTTOMBOUND					115

#define MAXFORCE					64
#define PLATFORMMASS				8

#define BALL_NUMBER					2
#define GRAVITY						0.2

// Structs
typedef struct
{
	/* data */
	int x_position;
	float y_position;
	int x_velocity;
	float y_velocity;

} ball_object;

typedef struct
{
	uint8_t center;
	uint8_t length;
	int x_velocity;
	int x_acceleration;
	uint8_t mass;
	/* data */
} platform_object;

//Game Options
//#define STICKY_PLATFORM
//#define DEBUGGING_STATS

void LCD_init(void);
void game_init(void);


#define MAX_STR_LEN							48

/////////


// CAPSENSE Channel 0 is
#define CSEN0_port gpioPortC
#define CSEN0_pin  0u
#define CSEN0_default false
// CAPSENSE Channel 1 is
#define CSEN1_port gpioPortC
#define CSEN1_pin  1u
#define CSEN1_default false
// CAPSENSE Channel 2 is
#define CSEN2_port gpioPortC
#define CSEN2_pin  2u
#define CSEN2_default false
// CAPSENSE Channel 3 is
#define CSEN3_port gpioPortC
#define CSEN3_pin  3u
#define CSEN3_default false
//////////

#endif  // BLINK_H
