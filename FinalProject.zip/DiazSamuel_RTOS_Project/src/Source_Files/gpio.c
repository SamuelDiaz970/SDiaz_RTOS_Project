//***********************************************************************************
// Include files
//***********************************************************************************
#include "gpio.h"

/***************************************************************************//**
 * @brief
 * configures the gpio pins
 *
 * @details
 * sets up drivestrength and pin modes for all in use gpios
 * these include the leds and the buttons
 *
 * @note
 * if any other gpio even interrupt is triggered we want to assert false because none of them should even be enabled
 *
 ******************************************************************************/
void gpio_open(void){

  // Set LED ports to be standard output drive with default off (cleared)
  GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthStrongAlternateStrong);
//  GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthWeakAlternateWeak);
  GPIO_PinModeSet(LED0_port, LED0_pin, gpioModePushPull, LED0_default);

  GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthStrongAlternateStrong);
//  GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthWeakAlternateWeak);
  GPIO_PinModeSet(LED1_port, LED1_pin, gpioModePushPull, LED1_default);

  GPIO_PinModeSet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN, gpioModeInput, false);
  GPIO_PinModeSet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN, gpioModeInput, false);

  	//Configure interrupts on GPIO
	GPIO_ExtIntConfig(BUTTON0_port, BUTTON0_pin, BUTTON0_pin, false, true, true);
	GPIO_ExtIntConfig(BUTTON1_port, BUTTON1_pin, BUTTON1_pin, false, true, true);

	/* Enable interrupt in core for even GPIO interrupts */
	NVIC_ClearPendingIRQ(GPIO_EVEN_IRQn);
	NVIC_EnableIRQ(GPIO_EVEN_IRQn);

	/* Enable interrupt in core for odd GPIO interrupts */
	NVIC_ClearPendingIRQ(GPIO_ODD_IRQn);
	NVIC_EnableIRQ(GPIO_ODD_IRQn);

}
